import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

export default function App() {
  const [selectedColor, setSelectedColor] = useState(null);
  const [showColors, setShowColors] = useState(false);

  const images = {
    red: require('./assets/red.png'),
    blue: require('./assets/blue.png'),
    silver: require('./assets/silver.png'),
    black: require('./assets/black.png'),
  };

  return (
    <View style={styles.container}>
      <Image
        source={selectedColor ? images[selectedColor] : images.blue}
        style={styles.image}
      />
      <Text style={styles.title}>Điện Thoại Vsmart Joy 3 - Hàng chính hãng</Text>
      <View style={styles.ratingContainer}>
        <View style={styles.stars}>
          {Array(5).fill().map((_, i) => (
            <Text key={i} style={styles.star}>★</Text>
          ))}
        </View>
        <Text style={styles.reviews}>(Xem 828 đánh giá)</Text>
      </View>
      <View style={styles.priceContainer}>
        <Text style={styles.price}>1.790.000 đ</Text>
        <Text style={styles.oldPrice}>1.790.000 đ</Text>
      </View>
      <View style={styles.refundContainer}>
        <Text style={styles.refundText}>Ở ĐÂU RẺ HƠN HOÀN TIỀN</Text>
        <Text style={styles.questionMark}>?</Text>
      </View>
      <TouchableOpacity
        style={styles.colorButton}
        onPress={() => setShowColors(!showColors)}
      >
        <Text style={styles.colorButtonText}>4 MÀU - CHỌN MÀU</Text>
      </TouchableOpacity>
      {showColors && (
        <View style={styles.colorsContainer}>
          <TouchableOpacity
            style={[styles.colorBox, { backgroundColor: 'red' }]}
            onPress={() => {
              setSelectedColor('red');
              setShowColors(false);
            }}
          />
          <TouchableOpacity
            style={[styles.colorBox, { backgroundColor: 'blue' }]}
            onPress={() => {
              setSelectedColor('blue');
              setShowColors(false);
            }}
          />
          <TouchableOpacity
            style={[styles.colorBox, { backgroundColor: 'silver' }]}
            onPress={() => {
              setSelectedColor('silver');
              setShowColors(false);
            }}
          />
          <TouchableOpacity
            style={[styles.colorBox, { backgroundColor: 'black' }]}
            onPress={() => {
              setSelectedColor('black');
              setShowColors(false);
            }}
          />
        </View>
      )}
      <TouchableOpacity style={styles.buyButton}>
        <Text style={styles.buyButtonText}>CHỌN MUA</Text>
      </TouchableOpacity>
      
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    padding: 16,
  },
  image: {
    marginTop: 40,
    width: 304,
    height: 400,
    borderRadius: 10,
    resizeMode: 'cover',
    
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 5,
    textAlign: 'center',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  stars: {
    flexDirection: 'row',
  },
  star: {
    color: 'yellow',
    fontSize: 20,
  },
  reviews: {
    marginLeft: 8,
    color: 'gray',
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  price: {
    color: 'red',
    fontSize: 20,
    fontWeight: 'bold',
  },
  oldPrice: {
    marginLeft: 8,
    color: 'gray',
    textDecorationLine: 'line-through',
  },
  refundContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  refundText: {
    color: 'red',
  },
  questionMark: {
    marginLeft: 4,
    color: 'red',
  },
  colorButton: {
    marginTop: 16,
    paddingVertical: 15,
    paddingHorizontal: 80,
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  colorButtonText: {
    marginRight: 8,
  },
  colorsContainer: {
    marginTop: 16,
    flexDirection: 'column',
    alignItems: 'center',
  },
  colorBox: {
    width: 48,
    height: 48,
    marginVertical: 4,
  },
  buyButton: {
    marginTop: 16,
    paddingVertical: 15,
    paddingHorizontal:110,
    backgroundColor: 'red',
    borderRadius: 15,
  },
  buyButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});
