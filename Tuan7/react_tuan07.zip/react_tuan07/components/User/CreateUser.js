import React, { useState } from "react";
import { View, TextInput, Button, StyleSheet, Text, ActivityIndicator, Alert } from "react-native";
import { useNavigation } from "@react-navigation/native";

const CreateUser = () => {
  const [user, setUser] = useState({ name: "", email: "", phone: "" });
  const [isLoading, setIsLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState(null);
  const navigation = useNavigation();
  const createUserApi = "http://localhost:3000/user"; // Adjust this for your backend

  const handleInput = (name, value) => {
    setUser({ ...user, [name]: value });
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(createUserApi, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(user),
      });

      if (!response.ok) {
        throw new Error("Failed to create user");
      }

      // Optionally reset the form
      setUser({ name: "", email: "", phone: "" });
      
      // Set success message
      setSuccessMessage("User created successfully!");

      // Navigate to ShowUser if desired
      // navigation.navigate("ShowUser");
      
      Alert.alert("Success", "User created successfully!");
    } catch (error) {
      Alert.alert("Error", error.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      {isLoading && <ActivityIndicator size="large" color="#0000ff" />}
      <TextInput
        placeholder="Name"
        onChangeText={(value) => handleInput("name", value)}
        style={styles.input}
        value={user.name}
      />
      <TextInput
        placeholder="Email"
        onChangeText={(value) => handleInput("email", value)}
        style={styles.input}
        value={user.email}
      />
      <TextInput
        placeholder="Phone"
        onChangeText={(value) => handleInput("phone", value)}
        style={styles.input}
        value={user.phone}
      />
      <Button title="Create User" onPress={handleSubmit} />
      {successMessage && <Text style={styles.successMessage}>{successMessage}</Text>}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { padding: 16 },
  input: { height: 40, borderColor: "gray", borderWidth: 1, marginBottom: 12, paddingHorizontal: 10 },
  successMessage: { marginTop: 10, color: "green", fontSize: 16 },
});

export default CreateUser;
