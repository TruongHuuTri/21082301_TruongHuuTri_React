import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  Image,
} from 'react-native';
import axios from 'axios';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons';

const mockApiUrl = 'https://671465c2690bf212c7615315.mockapi.io/api/ToDoList';

const TaskScreen = ({ route }) => {
  const { userName } = route.params;
  const [jobs, setJobs] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredJobs, setFilteredJobs] = useState([]);
  const navigation = useNavigation();

  useEffect(() => {
    axios
      .get(mockApiUrl)
      .then((response) => {
        setJobs(response.data);
        setFilteredJobs(response.data);
      })
      .catch((error) => console.error('Error loading jobs:', error));
  }, []);

  const addJobToList = (newJob) => {
    setJobs((prevJobs) => [...prevJobs, newJob]);
    setFilteredJobs((prevJobs) => [...prevJobs, newJob]);
  };

  const handleAddJob = () => {
    navigation.navigate('AddJobScreen', { userName, addJobToList });
  };

  const handleEditJob = (job) => {
    navigation.navigate('EditJobScreen', {
      job,
      userName,
      refreshJobs: (updatedJob) => {
        setJobs((prevJobs) =>
          prevJobs.map((j) => (j.id === updatedJob.id ? updatedJob : j))
        );
        setFilteredJobs((prevJobs) =>
          prevJobs.map((j) => (j.id === updatedJob.id ? updatedJob : j))
        );
      },
    });
  };

  const handleDeleteJob = async (id) => {
    try {
      await axios.delete(`${mockApiUrl}/${id}`);
      setJobs((prevJobs) => prevJobs.filter((job) => job.id !== id));
      setFilteredJobs((prevJobs) => prevJobs.filter((job) => job.id !== id));
    } catch (error) {
      console.error('Error deleting job:', error);
    }
  };

  const handleBack = () => {
    navigation.navigate('HomeScreen');
  };

  const handleSearch = (text) => {
    setSearchQuery(text);
    const filtered = jobs.filter((job) =>
      job.job.toLowerCase().includes(text.toLowerCase())
    );
    setFilteredJobs(filtered);
  };

  const renderItem = ({ item }) => (
    <View style={styles.jobItem}>
      <View style={styles.checkboxContainer}>
        <Icon name="checkmark" size={20} color="green" />
      </View>
      <Text style={styles.jobText}>{item.job}</Text>
      <TouchableOpacity onPress={() => handleEditJob(item)}>
        <Icon name="pencil" size={20} color="red" />
      </TouchableOpacity>
      <TouchableOpacity onPress={() => handleDeleteJob(item.id)}>
        <Icon name="trash" size={20} color="red" style={styles.deleteIcon} />
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <TouchableOpacity onPress={handleBack}>
          <Icon name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
        <View style={styles.profileContainer}>
          <Image
            source={{
              uri: 'https://sieupet.com/sites/default/files/pictures/images/1-1473150685951-5.jpg',
            }}
            style={styles.profileImage}
          />
          <View style={styles.greetingContainer}>
            <Text style={styles.header}>Hi {userName},</Text>
            <Text style={styles.subHeader}>Have a great day ahead!</Text>
          </View>
        </View>
      </View>
      <View style={styles.searchContainer}>
        <Icon name="search" size={20} color="#000" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search job"
          value={searchQuery}
          onChangeText={handleSearch}
        />
      </View>
      <FlatList
        data={filteredJobs}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderItem}
        contentContainerStyle={{ paddingBottom: 100 }}
      />
      <TouchableOpacity style={styles.addButton} onPress={handleAddJob}>
        <Text style={styles.addIcon}>+</Text>
      </TouchableOpacity>
    </View>
  );
};

export default TaskScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    width: '90%',
    justifyContent: 'space-between',
    paddingTop: 35,
  },
  profileContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  greetingContainer: {
    justifyContent: 'flex-start',
  },
  header: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  subHeader: {
    fontSize: 14,
    color: '#888888',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '90%',
    borderRadius: 30,
    paddingVertical: 8,
    paddingHorizontal: 15,
    marginBottom: 20,
    backgroundColor: '#EFEFEF',
  },
  searchIcon: {
    marginRight: 10,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 8,
    paddingLeft: 15,
    fontSize: 16,
    color: '#000',
  },
  jobItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    marginVertical: 5,
    width: 300,
    backgroundColor: '#E0E0E0',
    borderRadius: 5,
    justifyContent: 'space-between',
  },
  checkboxContainer: {
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'white',
    borderWidth: 2,
    borderColor: 'green',
    borderRadius: 5,
    marginRight: 15,
  },
  jobText: {
    fontSize: 18,
    flex: 1,
  },
  deleteIcon: {
    marginLeft: 10,
  },
  addButton: {
    position: 'absolute',
    bottom: 30,
    alignSelf: 'center',
    backgroundColor: '#00C4CC',
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
  },
  addIcon: {
    fontSize: 32,
    color: 'white',
    paddingBottom: 5,
  },
});
