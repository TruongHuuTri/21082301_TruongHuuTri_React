import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
} from 'react-native';
import axios from 'axios';
import { useNavigation, useRoute } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons';

const mockApiUrl = 'https://671465c2690bf212c7615315.mockapi.io/api/ToDoList';

const AddJobScreen = () => {
  const route = useRoute();
  const { userName, addJobToList } = route.params; // Get addJobToList function from params
  const [job, setJob] = useState('');
  const navigation = useNavigation();

  const handleFinish = () => {
    axios
      .post(mockApiUrl, { job })
      .then((response) => {
        addJobToList(response.data); // Gọi hàm này để cập nhật danh sách
        navigation.goBack(); // Trở lại màn hình sau khi cập nhật
      })
      .catch((error) => console.error('Error adding job:', error));
  };

  const handleBack = () => {
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerContainer}>
        <View style={styles.profileContainer}>
          <Image
            source={{
              uri: 'https://sieupet.com/sites/default/files/pictures/images/1-1473150685951-5.jpg',
            }}
            style={styles.profileImage}
          />
          <View>
            <Text style={styles.header}>Hi {userName},</Text>
            <Text style={styles.subHeader}>Have a great day ahead!</Text>
          </View>
        </View>
        <TouchableOpacity onPress={handleBack}>
          <Icon name="arrow-back" size={24} color="#000" />
        </TouchableOpacity>
      </View>

      {/* Add Job Input and Button */}
      <Text style={styles.title}>ADD YOUR JOB</Text>

      <View style={styles.inputContainer}>
        <Icon name="list" size={20} color="#32CD32" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Input your job"
          value={job}
          onChangeText={setJob}
        />
      </View>

      <TouchableOpacity style={styles.button} onPress={handleFinish}>
        <Text style={styles.buttonText}>FINISH</Text>
      </TouchableOpacity>

      <Image
  source={{ uri: 'https://s3-alpha-sig.figma.com/img/4d17/f963/f6ee0953600008083c32857b2d79ab5e?Expires=1730073600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=hS-ZlesIgOFsNI5TzKLXkZNFNd30uIpua1HUhRhIbtBCswHqgN3RenDxUmffeBVTigaFKAneh-4gUSJv2RiFFxfitfJujxSxJQEr2NKXHI4YTVsdVEIRolkIghXgOOngwgFgAiOBvMqI1QZOvqY4aF~SWJemmW6jsCCZvoKZvFmdOY-JON7u6PIX1AC3HUbTmHbp7N3-0R5SZsccTBPMOcDGrDtauJrQUwyT9vmPgmE0eqyBCbdZW1Sm-XMz2UYGHzENW29Q~eVJl4B~iA3Uo7sJv1KoG4D0pSa9-jPly8UCXNY0uycWzvgSktSEe-WsNTqlKACVmOq38s9GRRtKmQ__' }}
  style={styles.image}
/>
    </View>
  );
};

export default AddJobScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '90%',
    marginBottom: 20,
    position: 'absolute',
    top: 40,
  },
  profileContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  header: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  subHeader: {
    fontSize: 14,
    color: '#888888',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    marginTop: 80,
  },

  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '80%',
    marginBottom: 20,
    borderWidth: 1,
    borderRadius: 5,
    borderColor: '#CCCCCC',
  },

  icon: {
    paddingHorizontal: 10,
  },

  input: {
    flex: 1,
    padding: 10,
  },

  button: {
    backgroundColor: '#00C4CC',
    padding: 12,
    borderRadius: 30,
    width: '60%',
    alignItems: 'center',
    marginTop: 10,
  },

  buttonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
    image: {
    width: 200,
    height: 200,
    marginTop: 20, 
  },
});
