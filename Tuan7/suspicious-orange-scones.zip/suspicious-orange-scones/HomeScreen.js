import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons';

const HomeScreen = () => {
  const [name, setName] = useState('');
  const navigation = useNavigation();

  const handleGetStarted = () => {
    navigation.navigate('TaskScreen', { userName: name });
  };

  return (
    <View style={styles.container}>
      <Image source={{ uri: 'https://s3-alpha-sig.figma.com/img/4d17/f963/f6ee0953600008083c32857b2d79ab5e?Expires=1730073600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=hS-ZlesIgOFsNI5TzKLXkZNFNd30uIpua1HUhRhIbtBCswHqgN3RenDxUmffeBVTigaFKAneh-4gUSJv2RiFFxfitfJujxSxJQEr2NKXHI4YTVsdVEIRolkIghXgOOngwgFgAiOBvMqI1QZOvqY4aF~SWJemmW6jsCCZvoKZvFmdOY-JON7u6PIX1AC3HUbTmHbp7N3-0R5SZsccTBPMOcDGrDtauJrQUwyT9vmPgmE0eqyBCbdZW1Sm-XMz2UYGHzENW29Q~eVJl4B~iA3Uo7sJv1KoG4D0pSa9-jPly8UCXNY0uycWzvgSktSEe-WsNTqlKACVmOq38s9GRRtKmQ__' }} style={styles.image} />
      <Text style={styles.title}>MANAGE YOUR TASK</Text>
      <View style={styles.inputContainer}>
        <Icon name="mail-outline" size={20} color="#CCCCCC" style={styles.icon} /> {/* Biểu tượng bức thư */}
        <TextInput
          style={styles.input}
          placeholder="Enter your name"
          value={name}
          onChangeText={setName}
        />
      </View>
      <TouchableOpacity style={styles.button} onPress={handleGetStarted}>
        <Text style={styles.buttonText}>GET STARTED</Text>
      </TouchableOpacity>
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: 'purple',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '80%',
    marginBottom: 20,
    borderWidth: 1,
    borderRadius: 5,
    borderColor: '#CCCCCC',
    marginTop: 20,
  },
  icon: {
    paddingHorizontal: 10, 
  },
  input: {
    flex: 1,
    padding: 10,
  },
  button: {
    backgroundColor: '#00C4CC',
    padding: 10,
    borderRadius: 5,
    marginTop: 30,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  image: {
    width: 100,
    height: 100,
    marginBottom: 20,
  },
});
