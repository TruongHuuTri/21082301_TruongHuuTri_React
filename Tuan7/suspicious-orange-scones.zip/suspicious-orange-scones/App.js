import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './HomeScreen';
import TaskScreen from './TaskScreen';
import AddJobScreen from './AddScreen';
import EditJobScreen from './EditScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="HomeScreen">
        <Stack.Screen
          name="HomeScreen"
          component={HomeScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="TaskScreen"
          component={TaskScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="AddJobScreen"
          component={AddJobScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="EditJobScreen"
          component={EditJobScreen}
          options={{ headerShown: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
