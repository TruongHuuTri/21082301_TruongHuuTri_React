import React from 'react';
import { View, Text,TextInput, Image, FlatList, TouchableOpacity, StyleSheet, SafeAreaView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; // Đảm bảo bạn đã cài đặt @expo/vector-icons



const productData = [
  { id: '1', title: 'Cáp chuyển từ Cổng USB sang PS2...', price: '69.900 đ', discount: '-39%', rating: 4.5, reviews: 15, image: require('./giacchuyen1.png') },
  { id: '2', title: 'Cáp chuyển từ Cổng USB sang PS2...',price: '69.900 đ', discount: '-39%', rating: 4.5, reviews: 15, image: require('./daynguon1.png') },
  { id: '3', title: 'Cáp chuyển từ Cổng USB sang PS2...', price: '69.900 đ', discount: '-39%', rating: 4.5, reviews: 15, image: require('./dauchuyendoipsps21.png') },
  { id: '4', title: 'Cáp chuyển từ Cổng USB sang PS2...', price: '69.900 đ', discount: '-39%', rating: 4.5, reviews: 15, image: require('./dauchuyendoi1.png') },
  { id: '5', title: 'Cáp chuyển từ Cổng USB sang PS2...', price: '69.900 đ', discount: '-39%', rating: 4.5, reviews: 15, image: require('./carbusbtops21.png') },
  { id: '6', title: 'Cáp chuyển từ Cổng USB sang PS2...',price: '69.900 đ', discount: '-39%', rating: 4.5, reviews: 15,image: require('./daucam1.png') },
];

const ProductItem = ({item}) => (
  <View style = {styles.productItem}>
    <Image source = {item.image} style = {styles.image} />
    <Text>{item.title} </Text>
    <Text numberOfLines = {2} style={styles.productName}>{item.name} </Text>
    <View style={styles.ratingContainer}> 
      {[...Array(5)].map((_, i) => (
        <Ionicons key={i} name={i < Math.floor(item.rating) ? "star" : "star-outline" }size={12} color="#FFC120" />
      ))}
      <Text style={styles.reviewCount}>({item.reviews})</Text></View>
      <Text style={styles.productPrice}>{item.price}</Text>
      <Text style={styles.productDiscount}>{item.discount}</Text>
  </View>
);

const SearchScreen = () => {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="arrow-back" size={24} color="#1E88E5" />
        <View style={styles.searchBar}>
          <Ionicons name="search" size={20} color="#969696" />
          <TextInput 
            style={styles.searchInput}
            placeholder="Dây cáp usb"
            placeholderTextColor="#969696"
          />
        </View>
        <View style = {styles.ratingContainer}> 
        <Ionicons name="cart-outline" size={24} color="#1E88E5" />
        <Ionicons name="ellipsis-vertical" size={24} color="#1E88E5" />
        </View>
        
      </View>
      <FlatList
        data={productData}
        renderItem={({ item }) => <ProductItem item={item} />}
        keyExtractor={item => item.id}
        numColumns={2}
        columnWrapperStyle={styles.productRow}
      />
      <View style={styles.footer}>
        <Ionicons name="menu" size={24} color="#757575" />
        <Ionicons name="home" size={24} color="#757575" />
        <Ionicons name="return-up-back" size={24} color="#1E88E5" />
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F0F0F0',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    backgroundColor: 'white',
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0F0F0',
    borderRadius: 4,
    marginHorizontal: 10,
    paddingHorizontal: 10,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 8,
    marginLeft: 5,
  },
  productRow: {
    justifyContent: 'space-between',
    paddingHorizontal: 10,
  },
  productItem: {
    width: '48%',
    backgroundColor: 'white',
    marginVertical: 5,
    padding: 10,
    borderRadius: 4,
  },
  productImage: {
    width: '100%',
    aspectRatio: 1,
    borderRadius: 4,
  },
  productName: {
    marginTop: 5,
    fontSize: 14,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 5,
  },
  reviewCount: {
    fontSize: 12,
    color: '#757575',
    marginLeft: 5,
  },
  productPrice: {
    fontWeight: 'bold',
    marginTop: 5,
  },
  productDiscount: {
    color: 'red',
    fontSize: 12,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 10,
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
  },
});

export default SearchScreen;