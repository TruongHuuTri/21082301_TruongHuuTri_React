import React from 'react';
import { View, Text, Image, FlatList, TouchableOpacity, StyleSheet, SafeAreaView } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; // Đảm bảo bạn đã cài đặt @expo/vector-icons


const chatData = [
  { id: '1', title: 'Cà nấu lẩu, nấu mì mini...', shop: 'Shop Devang', image: require('./ca_nau_lau.png') },
  { id: '2', title: '1KG KHÔ GÀ BƠ TỎI ...', shop: 'Shop LTD Food', image: require('./ga_bo_toi.png') },
  { id: '3', title: 'Xe cần cẩu đa năng', shop: 'Shop Thế giới đồ chơi', image: require('./xa_can_cau.png') },
  { id: '4', title: 'Đồ chơi dạng mô hình', shop: 'Shop Thế giới đồ chơi', image: require('./do_choi_dang_mo_hinh.png') },
  { id: '5', title: 'Lãnh đạo giản đơn', shop: 'Shop Minh Long Book', image: require('./lanh_dao_gian_don.png') },
  { id: '6', title: 'Hiểu lòng con trẻ', shop: 'Shop Minh Long Book', image: require('./hieu_long_con_tre.png') },
];

const ChatItem = ({ item }) => (
  <View style={styles.chatItem}>
    <Image source={item.image} style={styles.productImage} />
    <View style={styles.chatInfo}>
      <Text style={styles.chatTitle} numberOfLines={1}>{item.title}</Text>
      <Text style={styles.shopName}>{item.shop}</Text>
    </View>
    <TouchableOpacity style={styles.chatButton}>
      <Text style={styles.chatButtonText}>Chat</Text>
    </TouchableOpacity>
  </View>
);

const ChatListScreen = () => {
  const renderItem = ({ item }) => <ChatItem item={item} />;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
      <Ionicons name="arrow-back" size={24} color="#7D7D7D" />
      <Text style={styles.headerTitle}>Chat</Text>
      <Ionicons name="cart" size={24} color="#7D7D7D" />
      </View>
      <FlatList
        data={chatData}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        ListHeaderComponent={() => (
          <View style={styles.notificationBar}>
            <Text style={styles.notificationText}>
              Bạn có thắc mắc với sản phẩm vừa xem đừng ngại chat với shop!
            </Text>
          </View>
        )}
      />
      <View style={styles.footer}>
  <Ionicons name="menu" size={24} color="#7D7D7D" />
  <Ionicons name="home" size={24} color="#7D7D7D" />
  <Ionicons name="return-up-back" size={24} color="#ee4d2d" />
</View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F1F1F1',
  },
  header: {
    flexDirection: 'row',
    justifyContent:'space-around',
    alignItems: 'center',
    backgroundColor: '#33CCFF',
    padding: 10,  
  },
  headerTitle: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
    
  },
  footer: {
  flexDirection: 'row',
  justifyContent: 'space-around',
  alignItems: 'center',
  backgroundColor: '#33ccff',
  padding: 10,
  borderTopWidth: 1,
  borderTopColor: '#F1F1F1',
},
  notificationBar: {
    backgroundColor: '#FFF7E5',
    padding: 10,
  },
  notificationText: {
    color: '#8E8E8E',
  },
  chatItem: {
    flexDirection: 'row',
    padding: 10,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#F1F1F1',
    alignItems: 'center',
  },
  productImage: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
  chatInfo: {
    flex: 1,
  },
  chatTitle: {
    fontWeight: 'bold',
  },
  shopName: {
    color: '#8E8E8E',
  },
  chatButton: {
    backgroundColor: '#ee4d2d',
    padding: 8,
    borderRadius: 4,
  },
  chatButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

export default ChatListScreen;