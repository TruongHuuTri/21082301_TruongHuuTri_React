import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { useDispatch } from 'react-redux';
import { setName } from '../store';
import Icon from 'react-native-vector-icons/MaterialIcons';

export default function WelcomeScreen({ navigation }) {
  const [nameInput, setNameInput] = useState('');
  const dispatch = useDispatch();

  const handleStart = () => {
    if (nameInput.trim()) {
      // Dispatch name and a default avatar to Redux
      dispatch(setName({ name: nameInput, avatar: 'https://picsum.photos/id/237/200/300' })); // Use a default avatar URL if needed
      navigation.navigate('Tasks');
    } else {
      Alert.alert("Error", "Please enter your name.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>MANAGE YOUR TASKS</Text>
      <View style={styles.inputContainer}>
        <Icon name="person" size={24} color="gray" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Enter your name"
          value={nameInput}
          onChangeText={setNameInput}
        />
      </View>
      
      <TouchableOpacity style={styles.button} onPress={handleStart}>
        <Text style={styles.buttonText}>GET STARTED</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center', 
    backgroundColor: '#f5f5f5',
  },
  title: { 
    fontSize: 24, 
    fontWeight: 'bold', 
    marginBottom: 20, 
    color: '#6200ee' 
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '80%',
    marginBottom: 20,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: 'gray',
    borderRadius: 8,
    backgroundColor: 'white',
  },
  icon: { 
    marginRight: 8 
  },
  input: { 
    flex: 1, 
    paddingVertical: 10, 
    fontSize: 16 
  },
  button: {
    backgroundColor: '#2ca39f',
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 8,
    marginTop: 15,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
