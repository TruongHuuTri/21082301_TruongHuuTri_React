import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
  Alert
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';

export default function AddTaskScreen({ navigation }) {
  const [taskName, setTaskName] = useState('');

  const handleAddTask = async () => {
  if (!taskName.trim()) {
    Alert.alert('Error', 'Please enter a task name');
    return;
  }

  console.log('Adding task:', taskName.trim());

  try {
    const response = await fetch('https://67133de66c5f5ced6625c506.mockapi.io/task', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: taskName.trim(),
        completed: false,
        createdAt: new Date().toISOString(),
      }),
    });

    if (response.ok) {
      const newTask = await response.json(); // Get the added task data
      console.log('Task added:', newTask);
      navigation.goBack(); // Navigate back to the task list
    } else {
      const errorData = await response.json(); // Get the error data
      Alert.alert('Error', `Failed to add task: ${errorData.message || 'Unknown error'}`);
    }
  } catch (error) {
    console.error('Error adding task:', error);
    Alert.alert('Error', 'Something went wrong');
  }
};


  return (
    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.container}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity 
            onPress={() => navigation.goBack()}
            style={styles.backButton}
          >
            <Icon name="arrow-back" size={24} color="#000" />
          </TouchableOpacity>
          <Text style={styles.title}>Add New Task</Text>
        </View>

        {/* Task Input Form */}
        <View style={styles.formContainer}>
          <Text style={styles.label}>Task Name</Text>
          <TextInput
            style={styles.input}
            value={taskName}
            onChangeText={setTaskName}
            placeholder="Enter task name"
            onSubmitEditing={handleAddTask}
          />

          {/* Add Button */}
          <TouchableOpacity 
            style={[styles.addButton, !taskName.trim() && styles.addButtonDisabled]}
            onPress={handleAddTask}
            disabled={!taskName.trim()}
          >
            <Text style={styles.addButtonText}>Add Task</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  backButton: {
    padding: 8,
    marginRight: 8,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  formContainer: {
    padding: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 8,
    color: '#333',
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 16,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#ddd',
    marginBottom: 24,
  },
  addButton: {
    backgroundColor: '#6200ee',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  addButtonDisabled: {
    backgroundColor: '#B39DDB',
    elevation: 0,
    shadowOpacity: 0,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});
