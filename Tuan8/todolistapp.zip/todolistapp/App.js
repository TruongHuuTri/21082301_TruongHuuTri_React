import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { Provider } from 'react-redux';
import store from './store';
import WelcomeScreen from './components/WelcomeScreen';
import TaskListScreen from './components/TaskListScreen';
import AddTaskScreen from './components/AddTaskScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <Provider store={store}>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Welcome">
          <Stack.Screen name="Welcome" component={WelcomeScreen} options={{ headerShown: false }} />
          <Stack.Screen name="Tasks" component={TaskListScreen} options={{ title: 'Manage Your Tasks' }} />
          <Stack.Screen name="AddTask" component={AddTaskScreen} options={{ title: 'Add Your Job' }} />
        </Stack.Navigator>
      </NavigationContainer>
    </Provider>
  );
}
