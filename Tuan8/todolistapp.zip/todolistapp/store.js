import { configureStore, createSlice } from '@reduxjs/toolkit';

const userSlice = createSlice({
  name: 'user',
  initialState: { name: '', avatar: null }, // Add avatar to initial state
  reducers: {
    setName: (state, action) => {
      state.name = action.payload.name; // Set name from payload
      state.avatar = action.payload.avatar; // Set avatar from payload
    },
  },
});

export const { setName } = userSlice.actions;

const store = configureStore({
  reducer: {
    user: userSlice.reducer,
  },
});

export default store;
