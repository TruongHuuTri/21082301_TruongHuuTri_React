import React, { useState } from 'react';
import { Text, StyleSheet, View, Image, TextInput, Button, Alert } from 'react-native';

const MyApp = () => {
  // Trạng thái để quản lý các trường nhập liệu
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Hàm xử lý đăng nhập
 const handleLogin = async () => {
    if (email === '' || password === '') {
      Alert.alert('Lỗi', 'Vui lòng nhập email và mật khẩu');
      return;
    }

    // Kiểm tra nếu email và mật khẩu đúng
    if (email === 'trimi@gmail.com' && password === '123') {
      // Lưu thông tin vào AsyncStorage
      await AsyncStorage.setItem('userEmail', email);
      Alert.alert('Đăng nhập thành công', 'Bạn đã đăng nhập thành công!');
    } else {
      Alert.alert('Lỗi', 'Email hoặc mật khẩu không chính xác');
    }
  };

  // Hàm để kiểm tra thông báo cookie
  const checkCookie = async () => {
    const storedEmail = await AsyncStorage.getItem('userEmail');
    if (storedEmail) {
      Alert.alert('Thông báo', `Bạn đã đăng nhập với email: ${storedEmail}`);
    } else {
      Alert.alert('Thông báo', 'Chưa có thông tin đăng nhập');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.css}>Everest Tour</Text>
  
      <Image source={{ uri: 'https://picsum.photos/seed/picsum/200/300' }} style={styles.img} />
      
      <Text style={styles.header}>Đăng Nhập</Text>
      
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />

      <TextInput
        style={styles.input}
        placeholder="Mật khẩu"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      
      <Button title="Đăng nhập" onPress={handleLogin} />

      <Text style={styles.footer}>Bạn chưa có tài khoản? Đăng ký</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#CC0033',
    justifyContent: 'flex-start',
    alignItems: 'center',
    padding: 20, // Thêm padding để tạo không gian
  },
  css: {
    fontSize: 16,
    color: '#00DD00',
    fontWeight: 'bold',
    height: 50,
    width: 200,
    backgroundColor: '#0000FF',
    padding: 10,
    borderWidth: 2,
    borderColor: 'black',
    marginBottom: 10,
    marginTop: 10,
    textAlign: 'center'
  },
  img: {
    height: 120,
    width: 200,
    borderRadius: 30,
    borderWidth: 2,
    borderColor: 'white',
    marginBottom: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#ffffff',
    
  },
  input: {
    width: '100%',
    padding: 10,
    marginBottom: 15,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    backgroundColor: '#fff',
  },
  footer: {
    marginTop: 20,
    color: '#007BFF',
  },
});

export default MyApp;
